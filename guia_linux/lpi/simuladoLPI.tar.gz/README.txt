@autor: Reginaldo de Matias
e-mail: reginaldo.matias@gmail.com

no Windows
Requisitos: ter o Dev C++ instalado
Extrair o arquivo, ir� criar o diret�rio com o mesmo nome
Na  IDE Dev C++, abre o arquivo, que acabou de extrair e tecle F9 para 
compilar.

no Linux
Requisitos: ter o compilador GCC instalado
Extrair, entre no diret�rio criado, compila e executa
$tar -xzvf simuladoLPI.tar.gz
$cd simuladoLPI
compilar
$gcc simulado.c -o simulado
executar
$./simulado

se quiser marcar o tempo, que levou para fazer o simulado
$time ./simulado
