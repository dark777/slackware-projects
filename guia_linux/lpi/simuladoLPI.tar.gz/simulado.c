/*	
Copyright 2009 Reginaldo de Matias
	Este programa � software livre; voc� pode redistribu�-lo e / ou
        modific�-lo sob os termos da GNU General Public License como
        publicada pela Free Software Foundation; tanto a vers�o 2
        Licen�a, ou (na sua op��o) qualquer vers�o posterior.

        Este programa � distribu�do na esperan�a que possa ser �til,
        mas SEM QUALQUER GARANTIA, sem mesmo a garantia impl�cita de
        COMERCIALIZA��O ou ADEQUA��O A UM DETERMINADO PROP�SITO. Veja a
        GNU General Public License para mais detalhes.

        Voc� deve ter recebido uma c�pia da GNU General Public
        License junto com este programa, se n�o, escreva para a
        Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
        02111-1307 E.U.A.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TRUE 1
#define FALSE 0
#define CORRETO 1
#define INCORRETO 0
int  abre_arq(int l);
void fecha_arq();
void exibe_perguntas();
int verifica_resposta(int resp_user,int resp_correta);
void simulado();
void mostra_resultado(int acertos, int erros,int n);
int gera_num();
int getRespostaUser();
FILE *arq=NULL;
int abre_arq(int l)
{
  if(l == 1)
  {
         arq = fopen("simulado_lpi101.txt","r+");
         if(arq != FALSE)
      return TRUE;
    return FALSE;
  }
  else 
  {
        arq = fopen("simulado_lpi102.txt","r+");
        if(arq != FALSE)
      return TRUE;
    return FALSE;
 }
}
void fecha_arq()
{
  fclose(arq);
}
void exibe_perguntas()
{
   char perg[200], resp1[100],resp2[100],resp3[100],resp4[100],resp5[100];
   int id,i,resp_correta,resp_user, acertos,erros, n,a;
   acertos=0; erros=0; n=1;
   while(!feof(arq)) /*enquanto n�o chegar no final do arquivo*/
   {
        fgets(perg,200,arq); /*l� pergunta do arquivo*/
        fgets(resp1,100,arq); /*l� alternativa 1 do arquivo*/
        fgets(resp2,100,arq); /*l� alternativa 2 do arquivo*/
        fgets(resp3,100,arq); /*l� alternativa 3 do arquivo*/
        fgets(resp4,100,arq); /*l� alternativa 4 do arquivo*/
        fgets(resp5,100,arq); /*l� alternativa 5 do arquivo*/
        fscanf(arq,"%i\n",&resp_correta); /*l� a resposta correta do arquivo*/
        system("clear"); /*limpa a tela*/
        printf("Pergunta %i\n",n); 
        
             printf("%s",perg); /*mostra a pergunta na tela lido do arquivo*/
             printf("1)%s",resp1); /*mostra a alternativa 1 na tela lido do arquivo*/
             printf("2)%s",resp2); /*mostra a alternativa 2 na tela lido do arquivo*/
             printf("3)%s",resp3); /*mostra a alternativa 3 na tela lido do arquivo*/
             printf("4)%s",resp4); /*mostra a alternativa 4 na tela lido do arquivo*/
             printf("5)%s",resp5); /*mostra a alternativa 5 na tela lido do arquivo*/
             n++; /*incrementa n para exibir o qtd de perguntas*/
             printf("Digite sua resposta: [1-5] "); 
             resp_user = getRespostaUser(); /*pega resposta do user*/
             if(verifica_resposta(resp_user,resp_correta) == CORRETO) /*checa a resposta do usu�rio com o gabarito 
da pergunta correspondente */
                acertos++;
             else
                erros++;
   }
     mostra_resultado(acertos,erros,n-1); /*desconta 1, pois n iniciou com 1*/   
}
int verifica_resposta(int resp_user,int resp_correta)
{
   if(resp_user == resp_correta)
       return CORRETO;
   return INCORRETO;
}
void mostra_resultado(int acertos,int erros,int n)
{
   float total;
   total = (acertos*100)/n;
   printf("%i acertos\n %i erros\n",acertos,erros);
   printf("Total: %5.2f%\n",total);
}
void simulado()
{
  int l;
  printf("Escolha qual simulado deseja fazer:\n[1]Exame LPI 101\n[2]Exame LPI 102\n");
  do{ scanf("%i",&l);
  }while(l<1 || l>2);
   if(abre_arq(l) == TRUE)
   {
         exibe_perguntas();
         fecha_arq();
   }
   else
    perror("Erro na leitura do arquivo\n");
}
int getRespostaUser()
{
  int ruser;
  do{
    scanf("%i",&ruser);
    }while(ruser<1 ||ruser>5);
    return ruser;
}
int main()
{
    simulado();
return 0;
}
