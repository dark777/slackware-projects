<?php
/** Copyright Information (GPL 3)
Copyright Stewart Watkiss 2012

This file is part of wQuiz.

wQuiz is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

wQuiz is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with wQuiz.  If not, see <http://www.gnu.org/licenses/>.
**/
?>
<html>
<head><title>Wquiz - not setup</title></head>
<body>
<h1>Wquiz - quiz setup incomplete</h1>
<p>Wquiz setup is incomplete. Please follow the instructions
included with the software or see the 
<a href="http://www.penguintutor.com">PenguinTutor Linux website</a>, <a href="http://www.penguintutor.com/wquiz">wquiz php web based quiz software</a>
for more details on how to complete the setup.
</p>
</body>
</html>
