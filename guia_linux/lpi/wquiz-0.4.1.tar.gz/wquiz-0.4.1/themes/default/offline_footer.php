<div id="wquiz-footer">
<p class="wquiz-createdby">
<a href="http://www.penguintutor.com/">Web Quiz (PHP) created by Stewart Watkiss<br/>Available from www.PenguinTutor.com</a>.
</p>
</div>

</div>
</body>
</html>
