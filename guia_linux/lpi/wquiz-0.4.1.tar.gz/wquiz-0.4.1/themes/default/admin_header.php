<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">

<meta name="description" content="WQuiz - quiz administration" />

<title>wQuiz - quiz administration</title>

<link href="%%ThemeDirectory%%wquiz.css" rel="stylesheet" type="text/css" />
<script src="../admin.js" type="text/javascript"></script>
<!-- Important to allow javascript include following javascript entry -->
%%HeaderJavascript%%
</head>

<body>
<img src="%%ThemeDirectory%%images/headerlogo.png" alt="wQuiz logo" />

<h1>Quiz administration</h1>



