<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">

<meta name="description" content="%%Description%%" />

<title>%%Title%% %%QuizTitle%% %%QuestionNumber%%</title>

<link href="%%ThemeDirectory%%wquiz.css" rel="stylesheet" type="text/css" />
<script src="wquiz.js" type="text/javascript"></script>
%%HeaderJavascript%%
</head>

<body>
<div id="internal">

<img src="%%ThemeDirectory%%images/headerlogo.png" alt="wQuiz logo">

