<div id="wquiz-adminfooter">
<a href="http://www.penguintutor.com"><img alt="PenguinTutor.com" style="float: left; border: 0px none; margin-top: 0px; margin-right: 10px;" src="%%ThemeDirectory%%images/createdby.png"/></a>

<p class="wquiz-createdby">
<a href="http://www.penguintutor.com/">Web Quiz (PHP) created by Stewart Watkiss<br/>Available from PenguinTutor.com</a>.
</p>
</div>

</body>
</html>
