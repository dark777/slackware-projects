** DO NOT EDIT ANY FILES IN THIS DIRECTORY. **

Any updates in this directory will be overwritten by future updates.


Instead copy the files to a new theme and update the theme_quiz (or theme_admin) setting to the new location. 