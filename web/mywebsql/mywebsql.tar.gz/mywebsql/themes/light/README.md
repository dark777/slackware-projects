MyWebSQL-Theme-light
====================

A grayish theme got MyWebSQL with a clean interface