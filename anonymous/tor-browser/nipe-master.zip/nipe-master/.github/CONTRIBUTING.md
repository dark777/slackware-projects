# Contributing to the Nipe!


## License

By opening a pull request in this repository, you agree to provide your work under the [project license](../LICENSE.md).

## Great Re-Writings

Open a discussion issue before you begin. So we can listen to what you have to say, and we can provide a referral if it will be worth changing big parts of the project.
